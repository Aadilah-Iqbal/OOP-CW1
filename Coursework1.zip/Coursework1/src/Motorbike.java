
public class Motorbike {

	int engineSize;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void brand(String motorbikeBrand){}
	public void entryTime(){}
	public void entryDate(){}
	public void engineSize(int motorBikeEngineSize){}
		// TODO Auto-generated method stub
	public void IDPlate(String motorbikeIDPlate) {
		// TODO Auto-generated method stub		
	}

		
	

}
