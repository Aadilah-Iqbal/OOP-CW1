import java.util.ArrayList;


public abstract class Vehicle {
	
	public static final int carLotSize=20;
	ArrayList<String> IDPlateNo = new ArrayList<String>(3);


	static String IDPlate;
	static String brand;
	int entryTime;
	
	abstract public void IDplate();
	abstract public void brand();
	abstract public void entryTime();
	abstract public void entryDate();
		// TODO Auto-generated method stub
		
	


}
