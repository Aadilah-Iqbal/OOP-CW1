import java.util.ArrayList;

public class Car extends Vehicle {

	ArrayList<String> CarNo2 = new ArrayList<String>(20);
	static String[] CarNo =  new String[carLotSize];
	static int[] carDoorNo = new int[carLotSize];
	static String[] carColour = new String[carLotSize];
	int doorNo;
	String colour;
	
	WestminsterCarParkManager WCPM=new WestminsterCarParkManager();
	public static void main(String[] args) {
	}

	public void IDPlate(String inputNo) {
		if(IDPlateNo.size()>=20){
			System.out.println("Exceeded parking space");
		}
		else{
			//	System.out.println("Printed in car");
				IDPlate=inputNo;
				//IDPlateNo.add(IDPlate);
			//	if(IDPlateNo.size()<3){
				System.out.println("");
		}
		
	}

	public void brand(String brand) {}

	public void entryTime() {}

	public void entryDate() {}

	public void doorNo(int inputNo) {
		//sends the car door nos to the array when the user inputs in wcpm.
		doorNo=inputNo;

}
	
	
	public void colour(String colour) {}

	@Override
	public void IDplate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brand() {
		// TODO Auto-generated method stub
		
	}



}
