
public class Van {

	int cargoVolume;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void brand(String vanBrand){}
	public void entryTime(){}
	public void entryDate(){}
	public void cargoVolume(int cargoVolume){}

	public void IDPlate(String vanIDPlate) {
		// TODO Auto-generated method stub
		
	}

}
