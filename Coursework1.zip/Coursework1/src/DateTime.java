
public class DateTime {

	int hours;
	int mins;
	int date;
	int month;
	int year;
	
	public DateTime(int hours, int mins, int date, int month, int year){
		this.hours=hours;
		this.mins=date;
		this.date=date;
		this.month=month;
		this.year=year;
		

	}


	public int getHours(){
		return hours;
	}
	public void setHours(int hours){
		this.hours=hours;
	}
	public int getMins(){
		return mins;
	}
	public void setMins(int mins){
		this.mins=mins;
	}
	public int getdate(){
		return mins;
	}
	public void setdate(int date){
		this.date=date;
	}
	public int getmonth(){
		return month;
	}
	public void setmonth(int month){
		this.month=month;
	}
	public int getyear(){
		return year;
	}
	public void setyear(int year){
		this.year=year;
	}
}
