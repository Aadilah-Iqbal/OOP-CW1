import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.StringTokenizer;


public class WestminsterCarParkManager {

	static Car car=new Car();
	static Van van=new Van();
	static Motorbike motorbike=new Motorbike();

	static int count;
	static ArrayList<String> IDPlateNo = new ArrayList<String>(20);
	static ArrayList<String> entryTimeDate = new ArrayList<String>(20);
	static ArrayList<String> brand = new ArrayList<String>(20);
	static ArrayList<String> carNo = new ArrayList<String>(20);
	static ArrayList<Integer> carDoorNo = new ArrayList<Integer>(20);
	static ArrayList<String> carColour = new ArrayList<String>(20);
	static ArrayList<String> vanNo = new ArrayList<String>(20);
	static ArrayList<Integer> cargoVol = new ArrayList<Integer>(20);
	static ArrayList<String> motorbikeNo = new ArrayList<String>(20);
	static ArrayList<Integer> engineSize = new ArrayList<Integer>(20);



	public static void main(String[] args) {
		String select = "";
		System.out.println("Do you wish to proceed: (yes/no)");
		Scanner sc = new Scanner(System.in);
		select = sc.next();
		while (select.equalsIgnoreCase("yes")) {
			// Display options to select from(the menu)
			System.out
			.println("1: Add a vehicle"
					+ "\n2: Delete a vehicle"
					+ "\n3: Calculate charges"
					+ "\n4: Print statistics"
					+ "\n5: Print the list of vehicles in a specified day");
			System.out
			.print("\nPlease select an option (a number from above) to proceed:");
			String userInput = sc.next();
			// Move in to the correct selection
			if (userInput.equals("1")) {
				addVehicle();
				//	storeVehicle();
			} else if (userInput.equals("2")) {
				deleteVehicle();
			} else if (userInput.equals("3")) {
				chargeVehicle();
			}
			else if (userInput.equals("4")) {
				System.out.println("\nPlease select an option (a letter from below) to proceed:");
				System.out.println("P: Percentage of vehicle type"
						+ "\nL: Current vehicle list");
					userInput = sc.next();
				if(userInput.equalsIgnoreCase("p")){
					percentage();
				}
				if(userInput.equalsIgnoreCase("L")){
					currentVehicleList();
				}
			}
		 else if (userInput.equals("5")) {
			 printSpecificList();
			 
		}
			else {
				System.out
				.println("\nPlease enter the correct number to proceed!");
			}

			System.out.println("Do you wish to proceed: (yes/no)");
			select = sc.next();
		}
	}
	private static void printSpecificList() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Date: \nDay:");
		int specDay=sc.nextInt();
		System.out.print("Month:");
		int specMonth=sc.nextInt();
		System.out.print("Year:");
		int specYear=sc.nextInt();
		File f=new File(specDay+""+specMonth+""+specYear+".txt");
		if(f.exists()){
		try {
		FileReader fR = new FileReader(f);
		BufferedReader reader=new BufferedReader(fR);
		String line=null;
		while((line=reader.readLine()) != null){
			System.out.println(line);
		}
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		else{
			System.out.println("No vehicles parked on "+specDay+"/"+specMonth+"/"+specYear);
		}
	}
	private static void chargeVehicle() {
		System.out.println("Enter ID plate number: ");
		Scanner sc = new Scanner(System.in);
		String input=sc.nextLine();
		System.out.print("Enter Current Time: \nHour:");
		int currHour=sc.nextInt();
		System.out.print("Minutes:");
		int currMin=sc.nextInt();

		if(IDPlateNo.contains(input)){
			int indexNo=IDPlateNo.indexOf(input);
			String enterTime=entryTimeDate.get(indexNo);

			int mins = 0;
			int hours = 0;
			int year;
			int month = 0;
			int date = 0;
			String delim=" ";
			StringTokenizer split=new StringTokenizer (enterTime,delim);
			while(split.hasMoreElements()){
				hours=Integer.parseInt(split.nextElement().toString());
				mins=Integer.parseInt(split.nextElement().toString());
				date=Integer.parseInt(split.nextElement().toString());
				month=Integer.parseInt(split.nextElement().toString());
				year=Integer.parseInt(split.nextElement().toString());			
			}
			double mintoHours=mins/60.0;
			double currMinToHours=currMin/60.0;
			double totHours=Math.ceil((currMinToHours+currHour)-(mintoHours+hours));
			double charge;
			if(totHours<=3){
				charge=totHours*3;}
			
			else{
				charge=(totHours-3)+9;
			}
			System.out.println("Id Plate:"+input+"\n"+"Final Price:"+charge);

		}	else {
				System.out.println("Vehicle ID no is not found...");	
	}
		}
	public static void addVehicle() {
		int mins=0;
		int hours = 0;
		int year = 0;
		int month = 0;
		int date = 0;
		System.out.println("Enter time of entry in the format hh mm dd mm yy:");
		Scanner sc = new Scanner(System.in);
		String entryTime=sc.nextLine();
		String delim=" ";
		StringTokenizer split=new StringTokenizer (entryTime,delim);
		while(split.hasMoreElements()){
			hours=Integer.parseInt(split.nextElement().toString());
			 mins=Integer.parseInt(split.nextElement().toString());
			 date=Integer.parseInt(split.nextElement().toString());
			  month=Integer.parseInt(split.nextElement().toString());
			 year=Integer.parseInt(split.nextElement().toString());
		}

		DateTime dateTime = new DateTime(mins,hours,date, month, year);
		
		entryTimeDate.add(entryTime);
		System.out.print("Enter the type of vehicle:(car/van/motorbike)");
		String input =sc.nextLine();
		System.out.println(entryTimeDate);
		try{
		File f = new File(date+""+month+""+year+".txt");

		if (!(f.exists())) {
			f.createNewFile();
			}

			FileWriter fw=new FileWriter(f,true);

			BufferedWriter bw=new BufferedWriter(fw);

		if (input.equals("car")){
			System.out.println("Enter ID Plate no: ");
			String carIDPlate=sc.nextLine();
			car.IDPlate(carIDPlate);
			bw.write("\nID plate no.: "+carIDPlate);
			bw.write("\nVehicle Type: "+input);
			
			System.out.println("Enter the brand of the car: ");
			String carBrand=sc.nextLine();
			car.brand(carBrand);			 
			System.out.println("Enter the number of doors:");
			int doorNo=sc.nextInt();
			car.doorNo(doorNo);
			System.out.println("Enter the colour of the car:");
			String colour=sc.next();
			car.colour(colour);
			if(count<20){
				IDPlateNo.add(carIDPlate);
				brand.add(carBrand);
				carNo.add(carIDPlate);
				carDoorNo.add(doorNo);
				carColour.add(colour);
				count++;
				System.out.println("Successfully completed...");
				System.out.println("No. of free lots available: "+(20-count));
			}
			else {
				System.out.println("Sorry no space available");
			}
		}
		else if (input.equals("van")){
			if (count<=18){
			System.out.println("Enter ID Plate no: ");
			String vanIDPlate=sc.nextLine();
			van.IDPlate(vanIDPlate);
			bw.write("\nID plate no.: "+vanIDPlate);
			bw.write("\nVehicle Type: "+input);

			System.out.println("Enter the brand of the van: ");
			String vanBrand=sc.nextLine();
			van.brand(vanBrand);			 
			System.out.println("Enter the cargo volume of the van:");
			int cargoVolume=sc.nextInt();
			van.cargoVolume(cargoVolume);
			if(count<20){
				IDPlateNo.add(vanIDPlate);
				brand.add(vanBrand);
				vanNo.add(vanIDPlate);
				cargoVol.add(cargoVolume);
				count+=2;
				System.out.println("Successfully completed...");
				System.out.println("No. of free lots available: "+(20-count));

			}
			else {
				System.out.println("Sorry no space available");
			}
			}
		}
		else if (input.equals("motorbike")){
			System.out.println("Enter ID Plate no: ");
			String motorbikeIDPlate=sc.nextLine();
			motorbike.IDPlate(motorbikeIDPlate);
			bw.write("\nID plate no.: "+motorbikeIDPlate);
			bw.write("\nVehicle Type: "+input);
			System.out.println("Enter the brand of the motor Bike: ");
			String motorbikeBrand=sc.nextLine();
			motorbike.brand(motorbikeBrand);			 
			System.out.println("Enter the engine size:");
			int motorBikeEngineSize=sc.nextInt();
			motorbike.engineSize(motorBikeEngineSize);
			if(count<20){
				IDPlateNo.add(motorbikeIDPlate);
				brand.add(motorbikeBrand);
				motorbikeNo.add(motorbikeIDPlate);
				engineSize.add(motorBikeEngineSize);
				count++;
				System.out.println("Successfully completed...");
				System.out.println("No. of free lots available: "+(20-count));
			}
			else {
				System.out.println("Sorry no space available");
			}	
			bw.write("\n");

		}
		else{
			System.out.println("Invalid type");
			}
		bw.close();

		
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}finally{
	}
	}

	
	public static void deleteVehicle(){
		System.out.println("Enter ID plate number: ");
		Scanner sc = new Scanner(System.in);
		String delInput=sc.nextLine();
		if(IDPlateNo.contains(delInput)){
			int vehicleIndexNoDel=IDPlateNo.indexOf(delInput);
			brand.remove(vehicleIndexNoDel);
			System.out.println(brand);
			entryTimeDate.remove(vehicleIndexNoDel);
			System.out.println(entryTimeDate);
			IDPlateNo.remove(IDPlateNo.indexOf(delInput));
			System.out.println(IDPlateNo);
		if(carNo.contains(delInput)){
			int carIndexNoDel=carNo.indexOf(delInput);
			System.out.println(carIndexNoDel);
			carDoorNo.remove(carIndexNoDel);
			carColour.remove(carIndexNoDel);
			carNo.remove(carNo.indexOf(delInput));
			count--;
				System.out.println("A car is leaving...");
				System.out.println(carDoorNo);
				System.out.println(carNo);
				System.out.println(carColour);

			}
	
		else if(vanNo.contains(delInput)){
				int vanIndexNoDel=vanNo.indexOf(delInput);
				cargoVol.remove(vanIndexNoDel);
				vanNo.remove(vanNo.indexOf(delInput));
				count-=2;
				System.out.println("A van is leaving...");

			}
			else if(motorbikeNo.contains(delInput)){
				int bikeIndexNoDel=motorbikeNo.indexOf(delInput);

				engineSize.remove(bikeIndexNoDel);
				motorbikeNo.remove(motorbikeNo.indexOf(delInput));
				count--;
				System.out.println("A motorbike is leaving...");
			}
			else {
				System.out.println("Vehicle ID no is not found...");
			}
			}
	}

	public static void percentage(){

		int noOfCar=carNo.size();
		int noOfVan=vanNo.size();
		int noOfMotorbike=motorbikeNo.size();
		double carPercentage;
		double vanPercentage;
		double motorbikePercentage;
		if(count>0){
		System.out.println("Car: "+(carPercentage=(noOfCar/count)*100.0)+"%");
		System.out.println("Van: "+(vanPercentage=(noOfVan/count)*100.0)+"%");	
		System.out.println("Motorbike: "+(motorbikePercentage=(noOfMotorbike/count)*100.0)+"%");	
	}
		else{
			System.out.println("Sorry no vehicles available in the parking lot");
		}
		}
	public static void currentVehicleList(){
		ArrayList<String> reverseID = new ArrayList<String>();
	//	ArrayList<String> reverseTime = new ArrayList<String>();
	/*	int mins = 0;
		int hours = 0;
		int year;
		int month = 0;
		int date = 0;*/
/*
		String delim=" ";
		StringTokenizer split=new StringTokenizer (delim);
		while(split.hasMoreElements()){
			hours=Integer.parseInt(split.nextElement().toString());
			mins=Integer.parseInt(split.nextElement().toString());
			date=Integer.parseInt(split.nextElement().toString());
			month=Integer.parseInt(split.nextElement().toString());
			year=Integer.parseInt(split.nextElement().toString());
		}*/
	for(int i=IDPlateNo.size()-1; i>=0;i--){
	reverseID.add(IDPlateNo.get(i));
//	reverseTime.add(IDPlateNo.get(i));
	}
		for(int i = 0;i<reverseID.size();i++){
/*			String currentTime=reverseTime.get(i);
			String delim=" ";
			StringTokenizer split=new StringTokenizer (currentTime,delim);
			while(split.hasMoreElements()){
			int	hours=Integer.parseInt(split.nextElement().toString());
			int	 mins=Integer.parseInt(split.nextElement().toString());
			int date=Integer.parseInt(split.nextElement().toString());
			int	  month=Integer.parseInt(split.nextElement().toString());
0			int	 year=Integer.parseInt(split.nextElement().toString());*/
			
		if(carNo.contains(reverseID.get(i))){
			System.out.println("Vehicle ID Plate No: "+reverseID.get(i)+"  Vehicle Type: Car");
		}
		if(vanNo.contains(reverseID.get(i))){
			System.out.println("Vehicle ID Plate No: "+reverseID.get(i)+"  Vehicle Type: Van");
		}
		if(motorbikeNo.contains(reverseID.get(i))){
			System.out.println("Vehicle ID Plate No: "+reverseID.get(i)+"  Vehicle Type: MotorBike");
		}
	}
	}
//	}
}

